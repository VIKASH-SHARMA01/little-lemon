# Android Developer Capstone Little Lemon App
This project is my final assignment in a course provided by Meta on Coursera. Here I am implementing an Android app for Little Lemon Restaurant.
